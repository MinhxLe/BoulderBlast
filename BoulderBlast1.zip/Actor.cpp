#include "Actor.h"
#include "StudentWorld.h"
#include "GameConstants.h"
#include <list>
#include <iostream>
using namespace std;
////////////ACTOR CLASS//////////
Actor::Actor(int imageID, int x, int y, Direction d)
:GraphObject(imageID, x, y, d){
	m_alive = true;
	setVisible(true);
}
Actor::~Actor(){}
bool Actor::isAlive(){
	return m_alive;
}
void Actor::die(){
	//getWorld()->destroyActor(this);
	m_alive = false;
}

void Actor::setWorld(StudentWorld* s){
	m_world = s;
}
StudentWorld* Actor::getWorld(){
	return m_world;
}

StudentWorld* Actor::m_world = nullptr;;

//////////ENTITY CLASS//////////
Entity::Entity(int imageID, int x, int y, Direction d, int h)
:Actor(imageID, x, y, d){
	m_health = h;
}
Entity::~Entity(){}
void Entity::doSomething(){
	if (!isAlive())
		die();
	else if (!action())
		move();
}
void Entity::takeDamage(){
	//play a sound
	setHealth(getHealth() - 1);
}
bool Entity::isAlive(){
	return m_health > 0;
}
void Entity::die(){
	//play a sound
	Actor::die();
}
bool Entity::moveDirection(Direction d){//change method isMovableTo
    setDirection(d);
    switch(d){
        case up:
            if (canMoveTo(getX(), getY()+1)){
                moveTo(getX(), getY()+1);
                //cout << "MOVING UP" << endl;
            	return true;}
            break;
        case down:
            if (canMoveTo(getX(), getY()-1)){
                moveTo(getX(), getY()-1);
            	return true;}
            break;
        case left:
            if (canMoveTo(getX()-1,getY())){
                moveTo(getX()-1, getY());
              //  cout << "MOVING LEFT" << endl;
            	return true;}
            break;
        case right:
            if (canMoveTo(getX()+1, getY())){
                moveTo(getX() +1, getY());
             //   cout << "MOVING RIGHT" << endl;
            	return true;}
            break;
        default:
            break;
    };
    return false;
}

bool Entity::canMoveTo(int x, int y) const{//empty
	//boundary outside
	if (x < 0 && x >= VIEW_WIDTH && y < 0 && y >= VIEW_HEIGHT)
		return false;
	//invalid objects to walk through
	list<Actor*> at = Actor::getWorld()->getActorAt(x,y);
	for (Actor* a : at){
		int id = a->getID();
		if (id != IID_AMMO && id != IID_JEWEL && id != IID_RESTORE_HEALTH
			&& id != IID_EXTRA_LIFE && id != IID_EXIT && id != IID_BULLET)
			return false; 
	}
	return true;
}

int Entity::getHealth() const{
	return m_health;
}
void Entity::setHealth(int h){
	m_health = h;
}

//////////VIOLENT CLASS//////////
violentEntity::violentEntity(int imageID, int x, int y, Direction d, int h)
:Entity::Entity(imageID, x, y, d, h){}
violentEntity::~violentEntity(){}
bool violentEntity::action(){
	//shoot here
	return true;
}
//////////PLAYER CLASS//////////
Player::Player(int x, int y)
:Entity(IID_PLAYER,x,y,right,20),violentEntity(IID_PLAYER, x, y, right, 20)
{
	m_ammo = 20;
}
Player::~Player(){}
void Player::doSomething(){
	            int ch;
            if (getWorld()->getKey(ch)){
                switch(ch){
                    case KEY_PRESS_LEFT:
                        moveDirection(left);
                        break;
                    case KEY_PRESS_RIGHT:
                        moveDirection(right);
                        break;
                    case KEY_PRESS_UP:
                        moveDirection(up);
                        break;
                    case KEY_PRESS_DOWN:

                        moveDirection(down);
                        break;
                    case KEY_PRESS_SPACE:
                        action();
                        break;
                    case KEY_PRESS_ESCAPE:
                        //die();
                        break;
                    default:
                        break;
                };
	}
}	
void Player::setAmmo(int a){
	m_ammo = a;
}
int Player::getAmmo() const{
	return m_ammo;
}
bool Player::action(){//shoot AND lose ammo//IMPLEMENT
	if (m_ammo > 0){
		setAmmo(m_ammo-1);
		return true;
	}
	return false;
}
 bool Player::move(){return true;}//?

 bool Player::canMoveTo(int x, int y) const{
	//boundary
	if (x < 0 && x >= VIEW_WIDTH && y < 0 && y >= VIEW_HEIGHT)
		return false;
	//invalid objects to walk through
	list<Actor*> at = getWorld()->getActorAt(x,y);
	for (Actor* a : at){
		int id = a ->getID();
		if (id != IID_AMMO && id != IID_JEWEL && id != IID_RESTORE_HEALTH
			&& id != IID_EXTRA_LIFE && id != IID_EXIT && id != IID_BULLET
			&& id != IID_BOULDER)
			return false;
		if (id == IID_BOULDER){
			bool x = dynamic_cast<Boulder*>(a)->moveDirection(getDirection());//move boulder in direction
			a->setDirection(none);//resets direction
			return x;
		}
	}
	return true;
 }

//////////WALL CLASS//////////
Wall::Wall(int x, int y)
	:Actor(IID_WALL, x, y, none){}
Wall::~Wall(){}
void Wall::doSomething(){}

//////////BOULDER CLASS//////////
Boulder::Boulder(int x, int y)
:Entity(IID_BOULDER, x, y, none, 10){}
Boulder::~Boulder(){}


bool Boulder::action(){
// fill a hole 
	list<Actor*> at = Actor::getWorld()->getActorAt(getX(), getY());
	for (Actor* a : at){
		if (a->getID() == IID_HOLE){
			a->die();
			setHealth(0);//HACKS
			//this->die();
			return true;
		}
	}
	//if current positition is hole, destroy hole and self
	//return true
	return false;
}
bool Boulder::move(){return false;}//boulders can't move on their own(duh)
bool Boulder::canMoveTo( int x,  int y) const{
	if (x < 0 && x >= VIEW_WIDTH && y < 0 && y >= VIEW_HEIGHT)
		return false;
	//invalid objects to walk through
	list<Actor*> at = getWorld()->getActorAt(x,y);
	for (Actor* a : at){
		int id = a ->getID();
		if (id != IID_AMMO && id != IID_JEWEL && id != IID_RESTORE_HEALTH
			&& id != IID_EXTRA_LIFE && id != IID_EXIT && id != IID_BULLET
			&& id != IID_HOLE)
			return false;
		
	}
	return true;
}

//////////HOLE CLASS//////////
Hole::Hole(int x, int y)
	:Actor(IID_HOLE, x, y, none){}
Hole::~Hole(){}
void Hole::doSomething(){}