#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include <string>
#include <map>
#include <list>
#include <iostream>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp
class Actor;
class Player;
class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir);
	~StudentWorld();

	virtual int init();
	virtual int move();
	virtual void cleanUp();

	Player* getPlayer() const;

	Actor* getActorAt(int x, int y, int actorType) const;
	void updatePosition(Actor* a);
//	void destroyActor(Actor* a);


private:
	struct loc{
		public:
		int m_x;
		int m_y;
		loc(int x,int y){
			m_x = x; m_y = y;
		}
		bool operator<(const loc& c) const{
			if (m_x < c.m_x)
				return true;
			else if (m_x > c.m_x)
				return false;

			else if (m_y < c.m_y)
				return true;
			else 
				return false;
		}
	};

	std::map<int, std::map<loc,Actor*> > m_actors;
	Player* m_player;
	int m_bonus;
	int m_jewelCount;

	void updateText();


};

#endif // STUDENTWORLD_H_
