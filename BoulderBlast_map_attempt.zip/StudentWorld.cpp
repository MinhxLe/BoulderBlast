#include "StudentWorld.h"
#include "Actor.h"
#include "Level.h"
#include <string>
#include <list>
#include <algorithm>
#include <sstream>
#include <iomanip>


using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}
StudentWorld::StudentWorld(string assetDir)
:GameWorld(assetDir){
	Actor::setWorld(this);
}
StudentWorld::~StudentWorld(){

	//NOTE: (*outer.second) is the inner map!!!!
	map<int , map<loc, Actor*> >::iterator outer = m_actors.begin();
	while (outer != m_actors.end()){//iterating through every "pair" of type to map
		map< loc, Actor*> innerMap = (*outer).second ;		
		map<loc, Actor*>::iterator inner = innerMap.begin();//every map
		while(inner != innerMap.end())//end of map
			delete ((*inner).second);//deleting dynamically allocated mem
		outer = m_actors.erase(outer);//deleting a pair (entire node)
	}
    delete m_player;
}
int StudentWorld::init(){
 	ostringstream lvl;
    lvl << "level" << setw(2) << setfill ('0') << getLevel() << ".dat";
    Level lev(assetDirectory());
    Level::LoadResult result = lev.loadLevel(lvl.str());
    //if level file was corrupt or not found
    if (result == Level::load_fail_file_not_found ||
            result == Level::load_fail_bad_format)
        return GWSTATUS_LEVEL_ERROR;
    //LOADING LEVEL
    
    //loading game actors and prviate data
    m_bonus = 1000;
    for (int x = 0; x < VIEW_WIDTH; x++)
	{
    for (int y = 0; y < VIEW_HEIGHT; y++) //CHECK IF RIGHT**WARNING PG. 14
        {
        	loc curr(x,y);
            switch(lev.getContentsOf(x,y))
            {
            case (Level::player):
                m_player = new Player(x,y);
                break;
            case (Level::wall):
            	m_actors[IID_WALL][curr] = new Wall(x,y);
            	break;
            case (Level::boulder):
            	m_actors[IID_BOULDER][loc(x,y)] = new Boulder(x,y);
            	break;
            // case (Level::hole):
            // 	m_actors[IID_HOLE][loc(x,y)] = new Hole(x,y);
            // 	break;
            default:
            	break;
            };
        }
    }

    //formatting text
    updateText();
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    //update text
    updateText();
    //update bonus
    if (m_bonus >0)
        m_bonus--;
    //actors doing shit
    //CAN CHANGE BECAUSE CERTAIN ACTORS IN MAP DON'T DO SHIT
	for (std::pair<int, map < loc, Actor*> > outer : m_actors){
		for (std::pair<loc, Actor* > inner : outer.second){
			(inner.second)->doSomething();//actor does something
		}

	}
    m_player->doSomething();

//    updating locations key for all actors
	for (pair<int, map < loc, Actor*> > outer : m_actors){
		for (std::pair<loc, Actor* > inner : outer.second){
			//cout << "updating from " << inner.second->getX() << " " << inner.second->getY() << " to ";
			int x = inner.first.m_x, y = inner.first.m_y;
			inner = std::pair<loc, Actor*>(loc(inner.second->getX(),inner.second->getY()) , inner.second);
			if (inner.second->getX() != x || inner.second->getY() != y)
				cout << "DIFFERENT" << endl;			
			//(loc(inner.second->getX(), inner.second->getY()) ,inner.second);
			//actor does something
		}
	}
	// map<int , map<loc, Actor*> >::iterator outer = m_actors.begin();
 //    while (outer != m_actors.end()){
 //   		map< loc, Actor*> innerMap = (*outer).second ;
	// 	map<loc, Actor*>::iterator inner = innerMap.begin();
	// 	while(inner != innerMap.end()){
	// 		Actor * curr =(*inner).second;
	// 		inner = innerMap.erase(inner);
	// 		innerMap[loc(curr->getX(), curr->getY())] = curr;
	// 		inner++;
	// 	}
	// 	outer++;
	// }



    //deleting dead actors
    //NO RANGE FOR TEST CAUSE DELETION
	map<int , map<loc, Actor*> >::iterator outer = m_actors.begin();
    while (outer != m_actors.end()){
   		map< loc, Actor*> innerMap = (*outer).second ;
		map<loc, Actor*>::iterator inner = innerMap.begin();
		while(inner != innerMap.end()){
			Actor * curr =(*inner).second; 
			if(!curr->isAlive()){//dead!
				delete (curr);//deleting dynamically allocated mem
				inner = innerMap.erase(inner);//deleting inner pair of
				//locinates and pointer to obj
			}
			inner++;
		}
		outer++;
	}

    if (m_player->isAlive()){
		m_player->doSomething();
		return GWSTATUS_CONTINUE_GAME;
	}

	else{
		decLives();
		return GWSTATUS_PLAYER_DIED;
	}
//below doesn't kill actors the moment they are killed, but on
//next tick(same thing really)
// it = m_actors.begin();
// while (it != m_actors.end()){
 //       	(*it)->doSomething();
 //       	it++;
 //    }
	  // while (it != m_actors.end()){
   //  	if ((*it)->isAlive()){
   //     		(*it)->doSomething();
   //     		it++;
   //     	}
   //     	else {
   //     		delete (*it);
   //     		it = m_actors.erase(it);
   //     	}
       	
   //  }

}

void StudentWorld::cleanUp()
{
	map<int , map<loc, Actor*> >::iterator outer = m_actors.begin();
	while (outer != m_actors.end()){//iterating through every "pair" of type to map
		map< loc, Actor*> innerMap = (*outer).second ;
		map<loc, Actor*>::iterator inner = innerMap.begin();//every map
		while(inner != innerMap.end())//end of map
			delete ((*inner).second);//deleting dynamically allocated mem
		outer = m_actors.erase(outer);//deleting a pair (entire node)
	}
    delete m_player;
}


//PRIVATE FUNCTIONS//
Actor* StudentWorld::getActorAt( int x, int y, int actorType) const{
	
	if (actorType == IID_PLAYER && m_player->getX() == x && m_player->getY() == y)
		return m_player;

	if (m_actors.find(actorType) == m_actors.end()){//could not find actor type
		return nullptr;
	}
	if ((m_actors.at(actorType).find(loc(x,y)))
	 == (m_actors.at(actorType).end()))//no actor type at that loc
		{
			return nullptr;
		}	
	else  
		return m_actors.at(actorType).at(loc(x,y));

	//CANNOT USE [] BECAUSE IT MIGHT CHANGE list
}

void StudentWorld::updateText(){
 	ostringstream gametxt;
    gametxt << "Score: " << setw(7) << setfill('0') << getScore() << "  ";
    gametxt	<< "Level: " << setw(2) << setfill('0') << getLevel() << "  ";
    gametxt << "Lives: " << setw(2) << setfill(' ') << getLives() << "  ";
    gametxt << "Health: " << setw(3) << setfill(' ') << m_player->getHealth() << "  ";
    gametxt << "Ammo: " << setw(3) << setfill(' ') << m_player->getAmmo() << "  ";
    gametxt << "Bonus: " << setw(4) << setfill(' ') << m_bonus << "  ";
    setGameStatText(gametxt.str());
}

